package com.kamohoaliix.Actions;

import com.kamohoaliix.Controllers.NodeHandler;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class RegenListener implements ActionListener {
    private NodeHandler nodeGen;

    public RegenListener(NodeHandler nodeGen) {
        this.nodeGen = nodeGen;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        this.nodeGen.newGeneration();
    }
}
