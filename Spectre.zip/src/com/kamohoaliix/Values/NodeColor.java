package com.kamohoaliix.Values;

public enum NodeColor {
    red, green, blue, orange, purple, yellow
}
